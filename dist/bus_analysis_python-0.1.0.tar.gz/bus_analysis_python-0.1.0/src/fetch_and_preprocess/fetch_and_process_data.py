from fetch_data import *
from process_data import *
from scheduled_function_runner import start

API_KEY = "539e0d6f-4b3f-4969-b1a7-1c50d903ff81"

if __name__ == '__main__':
    API_KEY = "" # w pliku .env
    # Fetch and process bus locations from time 8-9 and 12-13.
    start_hour_first, start_hour_second = 8, 12
    assert (0 <= start_hour_first <= 23 and 0 <= start_hour_second <= 23)

    fetch_and_save_bus_stops_coordinates(API_KEY)
    process_bus_stops_coordinates()

    fetch_and_save_buses_at_stops(API_KEY)
    process_buses_at_stops()

    start(start_hour_first, fetch_and_save_bus_locations, API_KEY)
    start(start_hour_second, fetch_and_save_bus_locations, API_KEY)
    process_bus_location_files()

    fetch_and_save_timetables(API_KEY)
    process_timetables(start_hour_first, start_hour_second)
